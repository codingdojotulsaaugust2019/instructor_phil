const Users = require('./../controllers/Users');

module.exports = (app) => {
  app.get('/', Users.index);
}
